<?php
define("DBHOST", "localhost");
define("DBUSER", "root");
//define("DBPASS", "root");
define("DBPASS", "");
define("DBNAME", "ex_eventos");
define("DBPORT", "3306");